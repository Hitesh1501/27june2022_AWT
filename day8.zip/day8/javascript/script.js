
function alertint(){
    alert('hello guys');
    document.body.style.backgroundColor="green";
    document.getElementById('js').style.backgroundColor='pink';
    }
    function confirmint(){
    confirm('hello guys');
    document.body.style.backgroundColor="blue";
    document.getElementById('js').style.backgroundColor='yellow';
    }
    function promptint(){
    prompt('hello guys');
    document.body.style.backgroundColor="orange";
     } 

     console.log(
        "hello"
     )
     document.getElementById('js').style.backgroundColor='pink';
     