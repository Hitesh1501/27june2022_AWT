$(document).ready(function () {
    $("#MyAccordion").accordion();
    $("#DOBpickar1").datepicker({
        showweek: true,
        yearsuffix: "(DOB)",
        showAnim: "slide"
    });

    $("#DOBpickar2").datepicker();
    $("#DOBpickar2").datepicker("show");

    $("#mybutton").click(function(){
        $("#mydiv").dialog({
        autoOpen:true,
        });
    });

    $("#text").spinner();
    
});